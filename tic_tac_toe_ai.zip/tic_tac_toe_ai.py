import math

HUMAN = 'O'
AI = 'X'
EMPTY = ' '

board = [EMPTY] * 9

def print_board(board):
    print("\n")
    for i in range(3):
        print(" | ".join(board[i*3:(i+1)*3]))
        if i < 2:
            print("---------")
    print("\n")

def is_winner(board, player):
    win_combos = [
        [0,1,2], [3,4,5], [6,7,8],
        [0,3,6], [1,4,7], [2,5,8],
        [0,4,8], [2,4,6]
    ]
    return any(all(board[pos] == player for pos in combo) for combo in win_combos)

def is_draw(board):
    return EMPTY not in board

def get_available_moves(board):
    return [i for i, spot in enumerate(board) if spot == EMPTY]

def minimax(board, depth, is_maximizing):
    if is_winner(board, AI):
        return 10 - depth
    elif is_winner(board, HUMAN):
        return depth - 10
    elif is_draw(board):
        return 0

    if is_maximizing:
        best_score = -math.inf
        for move in get_available_moves(board):
            board[move] = AI
            score = minimax(board, depth + 1, False)
            board[move] = EMPTY
            best_score = max(score, best_score)
        return best_score
    else:
        best_score = math.inf
        for move in get_available_moves(board):
            board[move] = HUMAN
            score = minimax(board, depth + 1, True)
            board[move] = EMPTY
            best_score = min(score, best_score)
        return best_score

def best_move(board):
    best_score = -math.inf
    move = None
    for i in get_available_moves(board):
        board[i] = AI
        score = minimax(board, 0, False)
        board[i] = EMPTY
        if score > best_score:
            best_score = score
            move = i
    return move

def human_turn():
    while True:
        try:
            move = int(input("Enter your move (1-9): ")) - 1
            if board[move] == EMPTY:
                return move
            else:
                print("Cell already taken. Try again.")
        except (ValueError, IndexError):
            print("Invalid input. Enter a number from 1 to 9.")

def play_game():
    print("Welcome to Tic-Tac-Toe!")
    print("You are O, AI is X.")
    print_board(board)
    
    current_turn = HUMAN

    while True:
        if current_turn == HUMAN:
            move = human_turn()
            board[move] = HUMAN
        else:
            print("AI is making a move...")
            move = best_move(board)
            board[move] = AI

        print_board(board)

        if is_winner(board, current_turn):
            print(f"{'Human' if current_turn == HUMAN else 'AI'} wins!")
            break
        elif is_draw(board):
            print("It's a draw!")
            break

        current_turn = HUMAN if current_turn == AI else AI

if __name__ == "__main__":
    play_game()
